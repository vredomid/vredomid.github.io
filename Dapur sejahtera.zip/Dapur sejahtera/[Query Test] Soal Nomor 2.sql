CREATE TABLE IF NOT EXISTS `detail_transaksi` (
  `id` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_transaksi` (`id_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT INTO `detail_transaksi` (`id`, `id_transaksi`, `harga`, `jumlah`, `subtotal`) VALUES
(1, '1', '25000', '1', '25000');

