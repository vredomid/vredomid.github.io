CREATE TABLE `transaksi` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_order` timestamp NULL DEFAULT NULL,
  `tanggal_pembayaran` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


INSERT INTO `transaksi` (`id`, `status`, `tanggal_order`, `tanggal_pembayaran`) VALUES
(1, 'lunas', '2021-12-27 23:31:40', '2021-12-27 23:31:40');

