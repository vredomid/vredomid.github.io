SELECT detail_transaksi.id, transaksi.tanggal_order, transaksi.status, transaksi.tanggal_pembayaran, detail_transaksi.subtotal, detail_transaksi.jumlah
FROM transaksi
INNER JOIN detail_transaksi ON transaksi.id = detail_transaksi.id;
